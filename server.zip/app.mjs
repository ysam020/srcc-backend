import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import insertNewTure from "./routes/post/insertNewTyre.mjs";
import tyreDetails from "./routes/tyreDetails.mjs";
// Post ***********************************************************************
import addVendor from "./routes/post/addVendor.mjs";
import addVehicle from "./routes/post/addVehicle.mjs";
import addTyreType from "./routes/post/addTyreType.mjs";
import addTyreSize from "./routes/post/addTyreSize.mjs";
import addTyreModel from "./routes/post/addTyreModel.mjs";
import addTyreBrand from "./routes/post/addTyreBrand.mjs";
import addRepairType from "./routes/post/addRepairType.mjs";
import addPlyRating from "./routes/post/addPlyRating.mjs";
import addDriverDetails from "./routes/post/addDriverDetails.mjs";
import tyreRepair from "./routes/post/tyreRepair.mjs";
import tyreBlast from "./routes/post/tyreBlast.mjs";
import tyreRetreading from "./routes/post/tyreRetreading.mjs";
import truckTyres from "./routes/post/addTruckTyres.mjs";
import driverAssignment from "./routes/post/driverAssignment.mjs";
// Get ***********************************************************************
import getVendors from "./routes/get/getVendors.mjs";
import getTyreModel from "./routes/get/getTyreModel.mjs";
import getTyreMake from "./routes/get/getTyreMake.mjs";
import getTyreType from "./routes/get/getTyreType.mjs";
import getTyreSize from "./routes/get/getTyreSize.mjs";
import getPlyRating from "./routes/get/getPlyRating.mjs";
import getTyreBrand from "./routes/get/getTyreBrand.mjs";
import tyreFitting from "./routes/post/tyreFitting.mjs";
import getTruckNumber from "./routes/get/getTruckNumber.mjs";
import getTyreNumber from "./routes/get/getTyreNumber.mjs";
import getRepairType from "./routes/get/getRepairType.mjs";
import getDrivers from "./routes/get/getDrivers.mjs";
import mailReport from "./routes/mailReport.mjs";
import rtoExpiryIntimation from "./routes/rtoExpiryIntimation.mjs";

import tyreWarrantyIntimaton from "./routes/tyreWarrantyIntimation.mjs";
import rto from "./routes/rto.mjs";
import getRto from "./routes/getRto.mjs";

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect(
    // "mongodb://localhost:27017/srcc",
    "mongodb+srv://sameery020:CId21lR1oWh6Od19@cluster0.pelnvme.mongodb.net/srcc?retryWrites=true&w=majority",
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  )
  .then(() => {
    app.use(insertNewTure);
    app.use(tyreDetails);
    app.use(addVendor);
    app.use(addVehicle);
    app.use(addTyreType);
    app.use(addTyreSize);
    app.use(addTyreModel);
    app.use(addTyreBrand);
    app.use(addRepairType);
    app.use(addPlyRating);
    app.use(addDriverDetails);
    app.use(tyreRepair);
    app.use(tyreBlast);
    app.use(tyreRetreading);
    app.use(truckTyres);
    app.use(driverAssignment);

    app.use(getVendors);
    app.use(getTyreModel);
    app.use(getTyreMake);
    app.use(getTyreType);
    app.use(getTyreSize);
    app.use(getPlyRating);
    app.use(getTyreBrand);
    app.use(getTruckNumber);
    app.use(getTyreNumber);
    app.use(getRepairType);
    app.use(getDrivers);

    app.use(tyreFitting);

    app.use(tyreWarrantyIntimaton);
    app.use(rto);
    app.use(mailReport);
    app.use(getRto);
    app.use(rtoExpiryIntimation);

    app.listen(8000, () => {
      console.log("Server is running on port 8000");
    });
  });
